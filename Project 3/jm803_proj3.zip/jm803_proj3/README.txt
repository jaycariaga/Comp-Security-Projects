DOCUMENTATION:
###################
Jason Cariaga
jmc803
171001720
###################

All programs conducted through python3 (successfully compiled thru 3.69, 3.8.3)
Run scripts like usual: ex.) python3 vencrypt.py keyfile..........

PROBLEMS with project:

from my knowledge everything works except for the last script: sbdecrypt.py
I cannot get the bytes to swap back into place properly